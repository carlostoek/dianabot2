
def is_admin(user_id, admin_ids):
    return user_id in admin_ids
